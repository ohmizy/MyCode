function hide(element) {
  element.remove ()
}

function hide(element) {
  element.remove ()
}

function likes (element){
  alert ('Ninja was liked')
}

function like (element){
  element.innerText++;
  }
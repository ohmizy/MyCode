function greetSomeone(person) {
        if (person == "Anakin") {
            console.log("Good day, Anakin!");
        }
        else {
                console.log("I'm coming for you, Dooku!");
            }
        }
        greetSomeone("Anakin");
        greetSomeone("Dooku");
        
var ChildHeightInInches = 52;
var ChildAge = 10;

function CanChildGetOnRide ()
if (ChildHeightInInches >= 52 & ChildAge >= 10) {
    console.log (Get_on_that_ride);
    elseif (ChildHeightInInches < 52 & ChildAge < 10)
    console.log (Sorry_kiddo. Maybe_next_year) ;
    
}

//Requirements in order for Child to be able to get on the ride. Child must be 10 years of age or older and be 52 inches tall or taller. 
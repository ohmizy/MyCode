for(var m = 2; m <= 6; m+=2) {
    console.log (m);   
} 

function hello() {
    console.log('hello');
}
hello();
console.log('Dojo');


function hello() {
    console.log('hello');
    return 15;
}
var result = hello();
console.log('result is', result);


function hello() {
    console.log('hello');
    return 15;
}
var result = hello();
console.log('result is', result);


function hello() {
    console.log('hello');
    return 15;
}
var result = hello();
console.log('result is', result);



function hello() {
    console.log('hello');
    return 15;
}
var result = hello();
console.log('result is', result);


function hello() {
    console.log('hello');
    return 15;
}
var result = hello();
console.log('result is', result);


function hello() {
    console.log('hello');
    return 15;
}
var result = hello();
console.log('result is', result);


function hello() {
    console.log('hello');
    return 15;
}
var result = hello();
console.log('result is', result);


function hello() {
    console.log('hello');
    return 15;
}
var result = hello();
console.log('result is', result);



function hello() {
    console.log('hello');
    return 15;
}
var result = hello();
console.log('result is', result);
